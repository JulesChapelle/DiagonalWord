﻿using DiagonalWord.Models;
using Microsoft.AspNetCore.Mvc;

namespace DiagonalWord.Controler
{
    public class DiagonalWordController : Controller
    {
        //First Page
        public IActionResult Index()
        {
            return View();
        }

        //Second Page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MyDiagonalWord(WordModel word)
        {
            return View(word);
        }
    }
}
