﻿using System.ComponentModel.DataAnnotations;

namespace DiagonalWord.Models
{
    public class WordModel
    {
        [Display(Name = "Choose a word")]
        public string DiagonalWord { get; set; }
    }
}
